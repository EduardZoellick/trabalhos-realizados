package uninter;

import java.util.Random;

public class ComputadorB extends Computador {
	//BitBot
	//numero deve ser par, e caso as possibilidades de par acabarem ele deve escolher um numero disponivel qualquer
	  
	
	public int jogarBit(int p) {//metodo de jogada do bitbot onde ele joga somente numeros pares
		   Random random = new Random();
		   while(true) {//cria��o do loop 
		   int numero2 = random.nextInt(1,9);//� gerado um valor aleat�rio entre 1 e 9 
		   if(numero2 % 2 == 0 ) {//caso a divis�o por 2, do numero em quest�o for igual a zero, ou seja o numero for par
			   System.out.println();
			   System.out.printf("(BITBOT) Vou jogar no %s",numero2);//o bot informa onde ir� jogar
			   System.out.println();
			   return numero2;  //o numero � retornado
		   }
			continue;//caso o numero n�o for par o loop � reiniciado 
		                }
        //caso o computador forne�a um valor inv�lido mais de 21 vezes, ele passa a jogar no modo padr�o (aleatoriamente um numero de 1 a 9)
                             }
	 
}
