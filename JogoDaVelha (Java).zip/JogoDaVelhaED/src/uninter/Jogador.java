package uninter;

public class Jogador {//classe jogador
private String nome;//atributo nome

public String getNome() {//getter do nome do jogador
	return nome;
}

public void setNome(String nome) {//setter do nome do jogador
	this.nome = nome;
}
}
