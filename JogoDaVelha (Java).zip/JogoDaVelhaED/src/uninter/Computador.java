package uninter;

import java.util.Random;

public class Computador {
public int jogar;
//classe m�e dos 3 computadores	
	 
//serve como refer�ncia base para os computadores
    public int jogar(int p) {
	   Random random = new Random();
	   int numero = random.nextInt(1,9);//gera��o de um numero aleatorio entre 1 a 9
	   System.out.println();
	   System.out.printf("Vou jogar no %s",numero);
	   System.out.println();
	   return  numero;//o valor gerado � retornado
	                   }
     

	}
