package uninter;

import java.util.Random;

public class ComputadorA extends Computador {
//Aston
//jogadas aleatorias e n�o categorizadas
	
@Override//Sobre escreve o metodo na classe m�e
	public int jogar(int p) {
		Random random = new Random();
		int numero = random.nextInt(1,9);//� gerado um numero aleat�rio entre 1 e 9
		if(numero <=3) {//se o numero for menor ou = a 3
			System.out.println();
			System.out.printf("(Aston) 'Como jupiter est� sobre Saturno vou jogar no %s'",numero);
			System.out.println();
			
		}
		else if(numero >4 && numero <=6) {//se o n�mero for maior que 4 e menor ou = a 6
			System.out.println();
			System.out.printf("(Aston) 'Tive uma vis�o do futuro vou jogar no %s'",numero);
			System.out.println();
		}
		else {//restante das op��es dipon�veis
			System.out.println();
			System.out.printf("(Aston) 'Segundo minha vizinha, vou jogar no %s'",numero);
			System.out.println();
		}
		return  numero;//o numero gerado � retornado
		
		
		}
	
}
	
 
	
	

