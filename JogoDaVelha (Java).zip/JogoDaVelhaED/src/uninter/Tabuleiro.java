package uninter;

public class Tabuleiro {
	private String[][] m = { {"1","2","3"},
			                 {"4","5","6"},
			                 {"7","8","9"} };//cria��o de uma matriz 3x3 a qual ser� base do jogo
	
	public String mostrar() {//tem como fun��o imprimir a tabela a qual � 'varrida' por cada linha e coluna
		for (int i = 0; i <3; i++) {
			for (int j = 0; j <3; j++) {
				System.out.printf("   "+ m[i][j]);
				
			}
		    System.out.println("");
		    System.out.println("");
		} 
		
		return null;
	}
	
	//validador de jogadas
     public boolean valido(String p) {//recebe uma string a qual representa a posi��o escolhida 
    	 for (int i = 0; i <3; i++) {
 			for (int j = 0; j <3; j++) {
 				if(m[i][j].equals(p))//caso ap�s a tabela ser varrida e for encontrado um espa�o com a posi��o escolhida a jogada � tida como v�lida
 					return true;
 			}
     }
    	 return false;//caso contrario a jogada � tida como inv�lida e retorna falso
     }
 
	public void jogada(String p, String j) {
		if(p.equals("1")) {//caso a jogada (string p) seja igual  a 1 a posi��o 0 0 na matriz ser� preenchida com o simbolo (string j) do jogador em quest�o  
			m[0][0]=j;//sendo 'X'jogador humano e '�' para o jogador computador
			} // a mesma logica se aplica ao restante alternando a posi��o dentro da matriz conforme
			else if(p.equals("2")) {
				m[0][1]=j;
		}
			else if(p.equals("3")) {
				m[0][2]=j;
		}
			else if(p.equals("4")) {
				m[1][0]=j;
		}
			else if(p.equals("5")) {
				m[1][1]=j;
		}
			else if(p.equals("6")) {
				m[1][2]=j;
		}
			else if(p.equals("7")) {
				m[2][0]=j;
		}
			else if(p.equals("8")) {
				m[2][1]=j;
		}
			else if(p.equals("9")) {
				m[2][2]=j;
		}
	}
	
	public void Limpjogadas() {//metodo para redefinir as posi��es da tabela para um novo jogo
		
			m[0][0]="1";
			m[0][1]="2";
			m[0][2]="3";
			m[1][0]="4";
			m[1][1]="5";	
			m[1][2]="6";
			m[2][0]="7";
			m[2][1]="8";
			m[2][2]="9";	
		
	}

	public String situacao(int jogadas) {//atua como 
		String[] T = new String[8];//cria��o de um vetor de 8 posi��es
		String vencedor = "null";
		if(jogadas == 9) {
			vencedor ="Empate";//caso todos os espa�oes sejam preenchidos e n�o haja nesse meio tempo um vencedor
		}
		T[0]= m[0][0] + m[0][1]+m[0][2];//os simbolos jogados ser�o concatenados detro do vetor de modo a cada linha adicionada representar uma posibilidade de vitoria, 
		T[1]= m[1][0] + m[1][1]+m[1][2];//no total temos 8 possibilidades de vitoria: na horizontal(3), e vertical(3), diagonal(2)
		T[2]= m[2][0] + m[2][1]+m[2][2];
		
		T[3]= m[0][0] + m[1][0]+m[2][0];
		T[4]= m[0][1] + m[1][1]+m[2][1];
		T[5]= m[0][2] + m[1][2]+m[2][2];
		
		T[6]= m[0][0] + m[1][1]+m[2][2];
		T[7]= m[0][2] + m[1][1]+m[2][0];
		
		for (int i = 0; i < T.length; i++) {
			if(T[i].equals("XXX")) {//ap�s a veredura, caso em algum vetor haja somente os simbolos 'X' o vencedor � o jogador humano
				vencedor = "Jogador humano";
			}
			else if(T[i].equals("���")) {//ap�s a varredura, caso em algum dos vetores haja somente simbolos '�' o vencedor � o computador
				vencedor ="Computador";
			   }
		   }
		return vencedor;//o metodo retorna o vencedor 
	}
	

}
