package uninter;

import java.util.Random;

public class ComputadorC extends Computador {
	//deve jogar numeros impares e caso esse acabem deve jogar qualquer outro dispon�vel

	public int jogarClare(int p) {//metodo de jogada da Clare onde ela joga somente numeros impares
		   Random random = new Random();
		   while(true) {
		   int numero = random.nextInt(1,9);//gerado um valor aleat�rio entre 1 e 9
		   if(numero % 2 > 0 ) {//caso a divis�o do n�mero por 2 resulte em maior que 0 
			   System.out.println();
			   System.out.printf("(CLARE) Vou jogar no %s",numero);//o bot informa onde ir� jogar
			   System.out.println();
			   return numero;//o numero � retornado  
		   }
			continue;  }
           }
   //Caso o bot forne�a valores invalidos mais de 21 vezes, o mesmo passa a jogar no modo padr�o (aleatoriamente um numero de 1 a 9)
	}


