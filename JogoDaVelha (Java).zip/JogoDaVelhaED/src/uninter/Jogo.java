package uninter;
import java.util.Scanner;

public class Jogo {//classe principal 

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);//instancia��o de um novo scanner
		Jogador jogador = new Jogador();//instancia��o de um novo jogador 
		final Tabuleiro tab = new Tabuleiro();//instancia��o de um novo tabuleiro
		String botNome = "nome";//variavel botNome para diferenciar os bots
	    int bitN = 0;//digito contador de jogadas do BitBot Computador(B)
	    int clareN = 0;//digito contador de jogadas da Clare Computador(C)
	    
		while(true) {//la�o de repeti��o principal para caso o jogador queira jogar de novo
			System.out.println("****Jogo da Velha****");
			int opcao = 0;//variavel op��o
			Computador comp = null;
		  while(true) {//la�o de repeti��o secundario para a escolha da dificuldade 
			  
			  System.out.println("[SYSTEM] Ol�, muito obrigado por jogar nosso jogo!");
			    System.out.println("[SYSTEM] Por favor, poderia informar seu nome ou nick?(sem espa�os se houver)");
			    String nick = teclado.next();//O nome/nick que o jogador digitar ser� definido como o nome do Jogador
			    jogador.setNome(nick);//comando de setar o nome do jogador
			    System.out.printf("[SYSTEM] Ok, muito obrigado %s, vamos prosseguir ent�o!\n",jogador.getNome());
				System.out.printf("[SYSTEM] %s Escolha uma dificuldade 1,2 ou 3:\n",jogador.getNome());//o comando getNome pega o nick que o jogador forneceu no inicio
				
				int op = teclado.nextInt();//A variavel 'op' recebe o input do teclado  
				if(op==1) {//caso 'op' for 1, o bot escolhido ser� o Aston (Computador A) 
					comp = new ComputadorA();
					System.out.println("[SYSTEM] A op��o 1 foi escolhida (Aston o Computador Louco)");
					botNome = "Aston";
					System.out.printf("(ASTON) Oi %s, voc� j� ficou sabendo que os marcianos est�o chegando?\n",jogador.getNome());
					System.out.println();
					break;// * o la�o de repeti��o ser� encerrado
					}
					else if(op==2) {//caso 'op' for 2, o bot escolhido ser� o BitBot (Computador B)
					comp = new ComputadorB();
					System.out.println("[SYSTEM] A op��o 2 foi escolhida (Bitbot o Computador que prefere os numeros pares)");
					botNome = "BitBot";
					System.out.printf("(BITBOT) Que fique claro %s, eu odeio n�meros impares, eles s�o t�o imperfeitos...\n",jogador.getNome());
					System.out.println();
					break;// * o la�o de repeti��o ser� encerrado
					}
				else if(op==3) {//caso 'op' for 3, o bot escolhido ser� a Clare (Computador C)
					comp = new ComputadorC();
					System.out.println("[SYSTEM] A op��o 3 foi escolhida (Clare o Computador que prefere os numeros impares)");
					botNome = "Clare";
					System.out.printf("(CLARE) Simplismente n�o curto numeros perfeitos %s, eles s�o t�o... tipo... n�!?\n",jogador.getNome());
					System.out.println();
					break; // * o la�o de repeti��o ser� encerrado 
						} 
				else {
					System.out.printf("[SYSTEM] Op��o inv�lida %s tente novamente!\n",jogador.getNome());
					continue; //Caso 'op' for diferente de 1, 2 ou 3, o la�o de repeti��o se reinicia
					
					}
		         }
		  
		System.out.println();
		String posi�ao;//variavel de posi��o
		int valida= 0,jogadas =0;//variaveis de velida��o e a do numero de jogadas
		tab.mostrar();//metodo de mostrar a tabela * N�o sei se procedi como deveria mas optei por deixar o metodo como sendo da classe tabela e n�o da classe jogador por conta da facilidade e agilidade na leitura e organiza��o 
		
		while(true) {//la�o de repeti��o do jogo em si
			System.out.println();
			
			
			do {//Jogador Humano| la�o do-while onde a verifica��o  do loop ocorre ap�s o codigo
			System.out.printf("[SYSTEM] %s voc� joga com o 'X', por favor informe uma posi��o para jogar (1 a 9): \n",jogador.getNome());
			posi�ao = teclado.next();//a posi��o de 1 a 9 ser� armazenada na variavel posi��o
			while(!tab.valido(posi�ao)) {//la�o de repeti��o| Caso a posi��o jogada seja diferente de valido/true o la�o permanecer� em loop
               System.out.println("[SYSTEM] Jogada inv�lida, tente denovo!");
			   System.out.printf("[SYSTEM] %s voc� joga com o ('X'), por favor informe uma posi��o para jogar (1 a 9): \n",jogador.getNome());
			   posi�ao = teclado.next();//novamente ser� armazenado e checado, e caso a posi��o for satisfeita o la�o ser� encerrado caso n�o o loop permanecer� 
			   valida = 0;//o valor de 'valida' permanecer� 0 renovando o la�o de repeti��o
			 }
			System.out.println();
			System.out.println("[SYSTEM] Jogada Validada!");
			System.out.println();
			tab.jogada(posi�ao, "X");//m�todo de jogada na tabela, informando a posi��o e o simbolo do jogador nesse caso o 'X' do Jogador humano
			valida = 1;//O valor de 'valida' � mudado e o la�o � encerrado
			}while(valida ==0);
			
			jogadas++;//O Numero de jogada � incrementado em +1
			valida = 0;//o valor de 'valida' � alterado para 0 novamente para o proximo jogo poder ser realizado
			tab.mostrar();//A tabela agora atualizada � mostrada no console
			if(!tab.situacao(jogadas).equals("null")) {//Caso a situa��o de jogadas for diferente de nulo, o la�o se encerrar�
				break;
			}      
			
		do {//Jogador Computador| Segue basicamente a mesma l�gica do jogador humano
			System.out.printf("[SYSTEM] %s voc� joga com ('�'), por favor informe uma posi��o para jogar (1 a 9): ", botNome);
			System.out.println();
			if(botNome == "Aston") {posi�ao = Integer.toString(comp.jogar(opcao));//A variavel posi��o receber� o valor convertido de inteiro para string referente a jogada do computador  
			}//*Como o computador retorna um valor em inteiro e a tabela � baseada em string, h� a necessidade de converter o valor em String
			else if(botNome == "BitBot") {//caso o computador seja o Bitbot seguir� a mesma logica, porem o modo de jogo ser� diferente
				posi�ao = Integer.toString(((ComputadorB) comp).jogarBit(opcao));
			}
			else if(botNome == "Clare") {//caso o computador seja a Clare seguir� a mesma logica, porem o modo de jogo ser� diferente
				posi�ao = Integer.toString(((ComputadorC) comp).jogarClare(opcao));
			}
			//o proprio bot fala qual posi��o ir� jogar;
			while(!tab.valido(posi�ao)) {//la�o de repeti��o caso a posi��o for diferente de valida o la�o se manter�
				if(botNome == "Aston") {//caso o nome do bot for "Aston" o jogo o trata de forma diferente
					System.out.println();
					System.out.println("[SYSTEM] Jogada inv�lida, essa op��o de Computador � meio louca...!");}
				else {//Caso o computador for outro
					System.out.println();
					System.out.println("[SYSTEM] Jogada inv�lida!");
				    System.out.printf("[SYSTEM] %s ,voc� joga com ('�') por favor informe uma posi��o para jogar (1 a 9): \n", botNome);
				     }
			    if(botNome == "Aston") {//caso o bot for o Aston 
			    posi�ao = Integer.toString(comp.jogar(opcao));//O bot jogar� qualquer numero inteiro entre 1 e 9 
			    //o proprio bot j� fala em qual posi��o ir� jogar
			    valida = 0;//O valor de valida � definido para 0 
			 }
			   else if(botNome == "BitBot"){//caso o nome do bot seja BitBot
					   while(true) {//la�o de repeti��o � definido infinito para o bot jogar at� a sua jogada ser v�lida
					   if (!tab.valido(posi�ao)) {//caso a posi��o jogada seja diferente de valido
						   if(bitN >=21) {//Caso o numero de jogadas do BitBot for maior ou igual a 21
						     posi�ao = Integer.toString(comp.jogar(opcao));//o bot passa a ter que jogar aleatoriamente qualquer numero inteiro entre 1 e 9
						     System.out.println(" (^~^) Aaaaah n�o! Agora vou passar a ter que usar esses n�meros horr�veis e imperfeitos  ");
						   } 
						   else {//Caso o numero de jogadas n�o satisfazer o 1 if
						   posi�ao = Integer.toString(((ComputadorB) comp).jogarBit(opcao));//O bot joga somente numeros Pares
						   bitN ++;//O numero de jogadas do BitBot e aumentado em +1
						   System.out.println("");
						   }
					   valida = 0;//O valor de valida � definido para zero 0
					   break;//O loop infinito � quebrado
					   
					   }
					   }
				   
				   }
			   else if(botNome == "Clare"){//Caso o nome do bot seja Clare | O sistema � basicamente o mesmo do BitBot 
				   while(true) {//la�o infinito at� o computador jogar uma jogada valida
					  if(!tab.valido(posi�ao)) {//caso a posi��o jogada seja diferente de valida 
						if(clareN >=21) {//Caso o numero de jogadas da clare for maior ou = a 21 o jogador passa a jogar aleatoriamente qualquer numero
							 System.out.println("(^~^) Aaaaah n�o! Agora vou passar a ter que usar esses n�meros horr�velmente perfeitos");
							 posi�ao = Integer.toString(comp.jogar(opcao));
						  }
						  else {//caso ainda n�o tenha chegado a 21
						  posi�ao = Integer.toString(((ComputadorC) comp).jogarClare(opcao));//O bot joga somente numeros impares
						  clareN ++;//O numero de jogadas da Clare e aumentado em +1
						  }
						valida = 0;//O valor de valida � definido para zero 0
						break;//O loop infinito � quebrado
					  } 
				      }
			   }
			   
			   }
			System.out.println();
			System.out.println("[SYSTEM] Jogada Validada!");
			System.out.println();
			tab.jogada(posi�ao, "�");//A posi��o escolhida pelo computador � jogada e o simbolo � � colocado no lugar escolhido
			valida = 1;//valida e definido para 1, quebrando o loop do-while
			} while(valida ==0);
			
			jogadas++;//ap�s a quebra do loop a variavel jogadas � incrementada em +1
			valida = 0;//o valor � retornado a 0 para dar inicio novamente ao jogo do jogador humano
			tab.mostrar();//a tabela atualizada � mostrada
			if(!tab.situacao(jogadas).equals("null")) {//caso a situa��o da tabela referente as jogadas seje diferente de nulo, o la�o de repeti��o do jogo em si se manter� em loop
				break;
			}
		}
			
        System.out.println("[SYSTEM] O "+ tab.situacao(jogadas)+ " venceu!");//ap�s o esgotamento do numero de jogadas, ser� definida a situa��o do tabuleiro 
        if(tab.situacao(jogadas) == "Jogador humano") {//caso o jogador humano tenha ganhado, ele receber� uma mensagem de parabeniza��o
        	System.out.printf("(%s) Parab�ns %s!, voc� me venceu! \n",botNome,jogador.getNome());
        }
        else if(tab.situacao(jogadas) == "Empate") {
        	System.out.println("[SYSTEM] Parab�ns aos jogadores, foi um jogo apertado!");
        
        }
        else if(botNome == "Aston"||botNome == "BitBot" && tab.situacao(jogadas)!="Empate"){//caso o computador ganhe, aparecer� uma mensagem do sistema o parabenizando
            System.out.println("[SYSTEM] Parab�ns " + botNome + " meu filho querido voc� venceu!");
            System.out.printf("(%s) Nunca ganhei nada na minha vida papai, acho que � um novo recorde pessoal! (;-;)",botNome);//gosto de adicionar um pouco de descontra��o para me alegrar um pouco, pe�o desculpas caso seja mal interpretado 
            }
        else if(tab.situacao(jogadas)!="Empate") {
        	System.out.println("[SYSTEM] Parab�ns " + botNome + " minha filha querida voc� venceu!");
        	System.out.printf("(%s) Nunca ganhei nada na minha vida papai, acho que � um novo recorde pessoal! (;-;)",botNome);
        }
		
        System.out.println();
		System.out.println();
		
		String control = "on";
		int ko = 0;
		do {
			System.out.println("[SYSTEM] Deseja jogar novamente? 1-Sim/0-N�o");//caso o jogador quira jogar novamente
			ko =teclado.nextInt();//ser� armazenado o valor digitado no teclado
			if(ko==0){//caso o valor digitado for igual a 0 o jogo ser� encerrado
					  System.out.println("[SYSTEM] Ok, muito obrigado por jogar nosso jogo, at� a proxima! :D");
					  System.out.println("(GAME OVER)");
					  System.exit(0);
				  }

		     if(ko!=1) {//caso o valor for diferente de 0 (subtentido) e tamb�m diferente de 1 o loop do while permanecer� at� informado uma op��o valida
		    	  System.out.printf("%s � um numero inv�lido para essa op��o, por favor digite (1-Sim/0-N�o)\n",ko);
		    	  continue;  
		                       }
			else if(ko==1) {//caso o valor digitado for igual a 1 o jogo ser� reiniciado
				  System.out.println("[SYSTEM] Ok, vamos l� de novo ent�o! :D");
				  System.out.println();
				  tab.Limpjogadas();// a tabela tem seu valores redefinidos para o padr�o 
				  bitN = 0;
				  clareN = 0;
				  control ="off";  }//a variavel control � definida para diferente de 'on' e o la�o do while � quebrado
		     } while(control == "on");
	    
	  if(control == "off") {
		  continue;//caso a op��o escolhida for a 1 o loop do inicio ser� reiniciado
	  }
		
		
		
	}
	}

	}

  	
		
			
		
		
		
	
		
		
			
	
	



